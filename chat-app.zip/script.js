window.createRoom = function () {
  const username = document.getElementById("username").value.trim();
  if (!username) return alert("Enter your name");

  const roomCode = Math.random().toString(36).substr(2, 6).toUpperCase();
  db.ref("rooms/" + roomCode).set({ messages: [] });
  joinChat(roomCode, username);
};

window.joinRoom = function () {
  const username = document.getElementById("username").value.trim();
  const roomCode = document.getElementById("roomCode").value.trim().toUpperCase();
  if (!username || !roomCode) return alert("Enter name and room code");

  db.ref("rooms/" + roomCode).get().then(snapshot => {
    if (!snapshot.exists()) return alert("Room not found");
    joinChat(roomCode, username);
  });
};

function joinChat(roomCode, username) {
  document.getElementById("chatSection").style.display = "block";
  const chatBox = document.getElementById("chatBox");
  chatBox.innerHTML = "";

  db.ref("rooms/" + roomCode + "/messages").on("value", snapshot => {
    chatBox.innerHTML = "";
    snapshot.forEach(child => {
      const msg = child.val();
      const div = document.createElement("div");
      div.textContent = msg.user + ": " + msg.text;
      chatBox.appendChild(div);
    });
    chatBox.scrollTop = chatBox.scrollHeight;
  });

  window.sendMessage = function () {
    const text = document.getElementById("messageInput").value.trim();
    if (!text) return;
    db.ref("rooms/" + roomCode + "/messages").push({ user: username, text });
    document.getElementById("messageInput").value = "";
  };
}
